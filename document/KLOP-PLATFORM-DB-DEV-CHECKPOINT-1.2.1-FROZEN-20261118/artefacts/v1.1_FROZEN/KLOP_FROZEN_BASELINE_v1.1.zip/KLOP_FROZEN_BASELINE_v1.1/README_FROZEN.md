# KLOP PLATFORM — FROZEN BASELINE v1.1

**Status:** FROZEN  
**Tanggal:** 18 November 2026 (Asia/Jakarta)  
**ID:** KLOP-PLATFORM-DB-FOUNDATION-1.1

## Tujuan
Snapshot tidak berubah dari dua file yang sudah dihasilkan di percakapan KLOP PROJECT. **Jangan mengedit file berlabel v1.1**. Semua pembaruan dibuat sebagai v1.2+ dengan change log dan versi script yang cocok.

## Ringkasan keputusan yang telah disepakati
- KLOP terdiri dari **KLOP Next** (React/Vite, SaaS frontend), **KLOP Platform** (ASP.NET Core Web API, penghubung bisnis/integrasi), **KLOP Core** (OCR AI berbasis Azure AI & Document Intelligence; dibangun belakangan).
- Model akhir **Hybrid SaaS**: akun **Personal** dan **Organization**, organization self-registration, identitas legal sesuai bentuk organisasi; bentuk organisasi tidak dibatasi pada PT/CV.
- **Global User** dan tenant membership sebagai relasi many-to-many di desain; fitur pengguna berpindah beberapa tenant / workspace diimplementasikan bertahap. Personal tenant dibatasi satu owner aktif.
- Database Microsoft SQL Server, master/configuration **database-driven**; akses/manipulasi data dengan **Stored Procedure**, backend dapat memakai Dapper. Database per environment.
- **Development dan Production saja**, bukan Staging. `appsettings` per environment untuk bootstrap non-secret; runtime business configuration di SQL Server; credentials & signing/encryption secrets di Azure Key Vault / secret manager sesuai deployment.
- Identity JWT + refresh tokens; otorisasi scoped role/permission, tenant isolation, least privilege.
- Logging terstruktur: audit/business/security events dan application logs; perubahan kritis diaudit secara transaksional; correlation ID. Log tidak memuat secrets.
- **Foundation v1.1:** 15 tabel master (`mst`) termasuk `OrganizationIdentityRequirementGroups`, serta 1 tabel `cfg.SystemConfigurations` = total **16** foundation tables.
- Persyaratan legalitas mendukung kelompok ALL/ANY/MINIMUM, effective dates, versioning dan riwayat verifikasi; tidak mengeksekusi query/kode dinamis dari data master.
- `cfg.SystemConfigurations`: validasi tipe/rentang nilai, status editable/sensitive/system, protection/approval policy untuk setting berisiko tinggi; secret di Key Vault, bukan nilai plaintext tabel.
- Governance role: scope PLATFORM vs TENANT, pemisahan tugas, larangan privilege escalation, audit perubahan permission, pelindungan owner terakhir.

## Lingkup yang **belum** dibekukan sebagai implementasi final
- Detail fisik tabel IAM/Tenant/Audit/Operations di luar master/configuration.
- Stored Procedure CRUD/transaksional/audit lengkap (ZIP mengandung Stored Procedure READ awal).
- Finalisasi kebijakan legal tiap yurisdiksi dan setup produksi SQL/Key Vault.
- Audit eksekusi script SQL Server, unit/integration tests, dan keputusan final target versi .NET yang didukung.

## Status script
`KLOP_Platform_SQL_v1.1.zip` = **draft script**, belum terbukti diuji pada SQL Server. Jangan deploy ke production tanpa review, perbaikan, dan pengujian pada Development. Versi script yang ada tidak diubah oleh proses freeze ini.

### Catatan kualitas draft
Ada nama Stored Procedure hasil generasi yang menggunakan suffix `Statuse` (contoh: `mst.usp_TenantStatuse_GetAll`); ini perlu diperbaiki pada versi berikutnya, **tanpa mengganti snapshot v1.1**.

## Cara melanjutkan dari percakapan baru
1. Tambahkan kedua file dan manifest ini ke **Project Files** di project KLOP PROJECT supaya menjadi referensi bersama; atau panggil nama berkas yang sama dari Library bila tersedia.
2. Nyatakan: `Gunakan baseline KLOP-PLATFORM-DB-FOUNDATION-1.1 (FROZEN). Jangan mengubah v1.1. Kita lanjut desain IAM/Tenant/Audit sebagai versi berikutnya.`
3. Setiap perubahan desain harus mencatat: versi baru, alasan, dampak ERD, dampak SQL, migrasi, risiko/security review, dan tanggal keputusan.

## Keaslian
Lihat `CHECKSUMS.sha256` atau `FROZEN_MANIFEST.json`. Hash SHA-256 menunjukkan file Excel dan SQL ZIP tidak diubah pada proses freeze. Bukan digital signature/garansi keamanan, hanya pemeriksaan integritas snapshot.
